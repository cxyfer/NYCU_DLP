# Implement your ResNet34_UNet model here

assert False, "Not implemented yet!"