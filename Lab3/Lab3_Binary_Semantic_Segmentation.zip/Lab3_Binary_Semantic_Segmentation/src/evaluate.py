def evaluate(net, data, device):
    # implement the evaluation function here

    assert False, "Not implemented yet!"