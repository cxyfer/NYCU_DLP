def dice_score(pred_mask, gt_mask):
    # implement the Dice score here
    
    assert False, "Not implemented yet!"

